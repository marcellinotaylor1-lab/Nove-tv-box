package com.novatv.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(7, 11, 22);
    private final int panel = Color.rgb(17, 25, 44);
    private final int accent = Color.rgb(115, 211, 255);
    private LinearLayout root, appRow;
    private TextView clock;
    private final List<AppEntry> apps = new ArrayList<>();
    private static class AppEntry {
        String label, pkg;
        AppEntry(String l, String p) { label=l; pkg=p; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildUI();
        loadApps();
    }

    private GradientDrawable shape(int color, int strokeColor, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (strokeColor != 0) d.setStroke(2, strokeColor);
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setFocusable(false);
        return t;
    }

    private void buildUI() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(42, 24, 42, 22);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(10,17,38), Color.rgb(19,19,48), bg}));
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("✦  NOVA TV", 25, accent, true);
        top.addView(logo, new LinearLayout.LayoutParams(0, 52, 1));
        clock = text("", 15, Color.LTGRAY, false);
        clock.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        top.addView(clock, new LinearLayout.LayoutParams(-2, 52));
        root.addView(top);
        updateClock();

        TextView eyebrow = text("YOUR ENTERTAINMENT UNIVERSE", 11, accent, true);
        eyebrow.setPadding(2, 12, 0, 0);
        root.addView(eyebrow);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(28, 20, 24, 20);
        hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{Color.rgb(32,50,91), Color.rgb(29,29,65), Color.rgb(13,18,35)}));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 148);
        hp.setMargins(0, 8, 0, 15);
        root.addView(hero, hp);

        TextView title = text("A BIG SCREEN. YOUR WORLD.", 25, Color.WHITE, true);
        hero.addView(title);
        TextView sub = text("Your apps, one beautiful home.", 14, Color.rgb(206,218,242), false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 32);
        hero.addView(sub, sp);
        TextView hint = text("Use the remote to choose an app below", 12, accent, false);
        hero.addView(hint);

        TextView appsTitle = text("YOUR APPS", 16, Color.WHITE, true);
        root.addView(appsTitle);
        TextView status = text("Installed apps appear here", 12, Color.LTGRAY, false);
        status.setTag("status");
        root.addView(status);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        appRow = new LinearLayout(this);
        appRow.setOrientation(LinearLayout.HORIZONTAL);
        appRow.setPadding(2, 9, 2, 10);
        hsv.addView(appRow);
        root.addView(hsv, new LinearLayout.LayoutParams(-1, 105));

        TextView footer = text("NOVA TV  •  LIGHTWEIGHT CINEMATIC HOME", 10, Color.rgb(128,143,173), true);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, new LinearLayout.LayoutParams(-1, 25));
    }

    private void updateClock() {
        if (clock != null) {
            clock.setText(new SimpleDateFormat("EEE, d MMM  •  HH:mm", Locale.getDefault()).format(new Date()));
            clock.postDelayed(this::updateClock, 60000);
        }
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> installed = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        for (ApplicationInfo ai : installed) {
            if (ai.packageName.equals(getPackageName())) continue;
            Intent launch = pm.getLaunchIntentForPackage(ai.packageName);
            if (launch != null) apps.add(new AppEntry(pm.getApplicationLabel(ai).toString(), ai.packageName));
        }
        Collections.sort(apps, Comparator.comparing(a -> a.label.toLowerCase(Locale.getDefault())));
        appRow.removeAllViews();
        for (AppEntry app : apps) {
            TextView tile = text(app.label, 14, Color.WHITE, true);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(12, 8, 12, 8);
            tile.setBackground(shape(panel, Color.rgb(43,59,91), 18));
            tile.setFocusable(true);
            tile.setClickable(true);
            tile.setContentDescription("Open " + app.label);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(150, 76);
            p.setMargins(0, 0, 12, 0);
            appRow.addView(tile, p);
            tile.setOnFocusChangeListener((v, focused) -> {
                v.setBackground(shape(focused ? Color.rgb(35,61,91) : panel,
                    focused ? accent : Color.rgb(43,59,91), 18));
                v.setScaleX(focused ? 1.04f : 1f);
                v.setScaleY(focused ? 1.04f : 1f);
            });
            tile.setOnClickListener(v -> launchApp(app.pkg));
            tile.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() == KeyEvent.ACTION_UP &&
                    (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) {
                    launchApp(app.pkg); return true;
                }
                return false;
            });
        }
        View status = root.findViewWithTag("status");
        if (status instanceof TextView) {
            ((TextView)status).setText(apps.isEmpty() ? "No launchable apps found." : apps.size() + " apps ready  •  Select a tile to launch");
        }
        if (!apps.isEmpty() && appRow.getChildCount() > 0) appRow.getChildAt(0).requestFocus();
    }

    private void launchApp(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) {
            try { startActivity(i); }
            catch (Exception e) {
                new AlertDialog.Builder(this).setMessage("This app could not be opened from NOVA TV.")
                    .setPositiveButton("OK", null).show();
            }
        }
    }
}
