# NOVA TV — Android TV launcher prototype

A lightweight native Android launcher prototype with a cinematic dark home screen, clock, installed-app tiles and D-pad focus navigation.

## Important
- This is source code, **not a prebuilt APK**. An APK must be built using Android Studio/Gradle on a computer.
- It is an early prototype. The visual hero is built-in artwork made from gradients; it does not scrape or stream movie catalogues.
- Android/Google TV versions differ in how they expose installed apps. If app discovery is incomplete on a particular firmware, package visibility may need adjustment.
- Installing a launcher does not automatically replace the Google TV home screen. Use Android's Home/default launcher settings if offered. Some TV firmware does not allow changing the default home app.
- No Downloader code is available until the APK is built and hosted at a stable HTTPS download URL. Do not enter a guessed code in Downloader.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Allow Gradle sync; use JDK 17 and Android Gradle Plugin 8.7.3.
4. Build > Build APK(s).
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Install on Xiaomi TV Box 2nd Generation
1. Copy the APK to a USB drive, or transfer it over your local network.
2. On the box, allow installation for the file manager you use under Settings > Apps > Special app access > Install unknown apps (wording may vary).
3. Open the APK and install it.
4. Launch NOVA TV from Apps.
5. Test left/right/up/down, OK, Back and app launching.

## Downloader
Downloader needs a direct HTTPS URL or a short code registered with a hosting service. This project has not been built or hosted by this chat, so there is no valid Downloader code yet. Do not use a made-up code.

## Build without installing Android Studio (GitHub Actions)
This project includes `.github/workflows/build-apk.yml`.
1. Sign in to GitHub and create a new repository named `NOVA-TV`.
2. Upload the **contents** of this ZIP to the repository (not the ZIP itself), committing them to the `main` branch.
3. Open the repository's **Actions** tab and select **Build NOVA TV APK**. Choose **Run workflow** if it has not started automatically.
4. When the workflow succeeds, open that run and download the `NOVA-TV-debug-APK` artifact. Extract it to get `app-debug.apk`.
5. Transfer the APK to your Xiaomi TV Box and install it.

The artifact is a debug APK for testing, not a Play Store release. GitHub Actions does not create a Downloader short code. For Downloader, the APK must be uploaded to a stable public HTTPS file URL, or registered with a short-code service. Never enter an unverified code.
